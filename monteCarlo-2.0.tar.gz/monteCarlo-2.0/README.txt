Version 1.3
GUI is writing config.ini now
To run it, please run plot.py
