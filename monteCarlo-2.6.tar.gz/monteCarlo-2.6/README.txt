Version 2.6
Serious fixes of algorithm, now it`s looks correct
Eps now is variable
To run it, please run plot.py
