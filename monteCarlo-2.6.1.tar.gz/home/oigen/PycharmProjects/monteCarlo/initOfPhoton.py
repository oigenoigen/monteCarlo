import math
import random
import numpy
import cmath
from configRead import config_read


class Photon:
    """Describes photon"""
    def __init__(self):
        """Initialization of photon"""
        config = config_read()
        #initial coordinates
        self.x=float(config['photon']['x'])
        self.y=float(config['photon']['y'])
        self.z=float(config['photon']['z'])
        #initial directions
        self.ux=float(config['photon']['ux'])
        self.uy=float(config['photon']['uy'])
        self.uz=float(config['photon']['uz'])
        #initial step
        self.step=float(config['photon']['step'])
        #initial coef of anizotropy
        self.g=float(config['photon']['g'])
        #initial weight
        self.w=float(config['photon']['w'])
        #refraction index
        self.n=float(config['photon']['n'])
        global eps#rewriting eps!!!bad practice
        eps=float(config['GLOBAL']['eps'])


    def hop(self,tissue):
        """change photon location"""
        self.step=-math.log(random.random())/(tissue.adA+tissue.adS)
        #test coordinate to check if photon is crossing borders
        z=self.z+self.step*self.uz
        """if photon hit the boundary, checkBoundary() function placing it ON the boundary,
        calculate w value and changing uz to -uz
        If no, just calculating new step(else case)
        """
        if numpy.real(z)>=tissue.D:
            self.checkBound(tissue,bound=tissue.D)
        elif numpy.real(z)<=0:
            self.checkBound(tissue,bound=0)
        else:
            self.z += self.step * self.uz
            self.x += self.step * self.ux
            self.y += self.step * self.uy
        return self

    def spin(self):
        """Changing photon direction"""
        g=self.g
        costeta=((1+(g**2))-((1-(g**2))/((1-g+2*g*random.random())**2)))/(2*g)
        sinteta=cmath.sqrt(1-costeta**2)
        temp=cmath.sqrt(1-self.uz**2)
        fi=2*math.pi*random.random()
        #recalculation of ux,uy,uz if vector is like 0,0,1
        if numpy.real(self.ux) < eps and numpy.real(self.uy) < eps:
            uxx=sinteta*math.cos(fi)
            uyy=sinteta*math.sin(fi)
            if numpy.real(self.uz) >=0:
                uzz=costeta
            else:
                uzz=-costeta
        else:
            #other cases
            uxx = sinteta * (self.ux * self.uz * math.cos(fi) - self.uy * math.sin(fi)) / temp + self.ux * costeta
            uyy = sinteta * (self.uy * self.uz * math.cos(fi) + self.ux * math.sin(fi)) / temp + self.uy * costeta
            uzz = -sinteta * math.cos(fi) * temp + self.uz * costeta


        norm=cmath.sqrt(uxx**2+uyy**2+uzz**2)
        #normalization
        self.ux = numpy.real(uxx / norm)
        self.uy = numpy.real(uyy / norm)
        self.uz = numpy.real(uzz / norm)
        return self

    def drop(self,tissue):
        self.w*=(tissue.adS/(tissue.adA+tissue.adS))
        #roulette
        if self.w<eps*100:
            RND=random.random()
            if RND<=0.1:
                self.w/=0.1
            else:
                self.w=0

        return self

    def checkBound(self,tissue,bound):
        self.step=abs((bound-self.z)/self.uz)
        self.x += self.step * self.ux
        self.y += self.step * self.uy
        self.z += self.step * self.uz

        costeta1=self.uz
        sinteta1=cmath.sqrt(1-self.uz**2)
        sinteta2=cmath.sin(tissue.n/self.n)
        costeta2=cmath.sqrt(1-sinteta2**2)
        #here I`ll split formula for R to make it easier to read
        var1=sinteta1*costeta2
        var2=costeta1*sinteta2
        var3=costeta1*costeta2
        var4=sinteta1*sinteta2

        R1=((var1-var2)**2)/2
        R2=((var3+var4)**2)+((var3-var4)**2)
        R3=((var1+var2)**2)*((var3+var4)**2)

        R=R1*(R2/R3)

        if numpy.imag(R)!=0:
            R = 1
        #here we have to use real(R) because cmath.sqrt(real) returns real+0*img
        result=0
        if numpy.real(R)<random.random():
            result=self.w
            self.w=0


        self.uz=-self.uz

        if bound>0:
            indX=(self.x-(-0.5))/tissue.binSize
            indY = (self.y - (-0.5)) / tissue.binSize
            if indX>=200:
                indX=199
            if indX<=0:
                indX=0
            if indY>=200:
                indY=199
            if indY<=0:
                indY=0
            indX=int(indX)
            indY=int(indY)
            tissue.matrix[indX][indY]+=result

        return self,tissue











