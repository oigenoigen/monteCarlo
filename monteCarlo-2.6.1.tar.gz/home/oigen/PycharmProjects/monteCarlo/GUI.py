from tkinter import *
from dataRead import readFromFile
from getDictVal import  getDictVal
import configparser
import os


class gui(Tk):
    def __init__(self):
        Tk.__init__(self)
        self.initialize()
        self.mainloop()


    def initialize(self):


        self.adiposeAbsorbtion = readFromFile("adipose_absorbtion.txt")
        self.adiposeScattering = readFromFile("adipose_scattering.txt")
        self.bloodAbsorbtion = readFromFile("blood_absorbtion.txt")
        self.bloodScattering = readFromFile("blood_scattering.txt")


        self.title("Select the wavelength")
        self.geometry('500x400+300+200')

        self.adiposeAbsorbtionLabel = Label(self,text="")
        self.adiposeAbsorbtionLabel.place(x=200, y=150)

        self.adiposeScatteringLabel = Label(self,text="")
        self.adiposeScatteringLabel.place(x=200, y=200)

        self.bloodAbsorbtionLabel = Label(self,text="")
        self.bloodAbsorbtionLabel.place(x=200, y=250)

        self.bloodScatteringLabel = Label(self,text="")
        self.bloodScatteringLabel.place(x=200, y=300)

        self.wLScale = Scale(self, orient=HORIZONTAL, command=self.getValues, length=300, from_=300, to=900, tickinterval=50)
        self.wLScale.place(x=100, y=50)

        self.exitButton = Button(self, text="Build plot", command=self.closeGui)
        self.exitButton.place(x=100, y=225)

    def getValues(self,scaleValue):
        wl=float(scaleValue)
        #wl=self.wLScale.get()

        self.adA=getDictVal(wl,self.adiposeAbsorbtion)*10
        self.adS=getDictVal(wl,self.adiposeScattering)*10
        self.blA=getDictVal(wl,self.bloodAbsorbtion)*10
        self.blS=getDictVal(wl,self.bloodScattering)*10

        self.adiposeAbsorbtionLabel.config(text='adipose absorbtion is %s mm^-1'%self.adA)
        self.adiposeScatteringLabel.config(text='adipose scattering is %s mm^-1'%self.adS)
        self.bloodAbsorbtionLabel.config(text='blood absorbtion is %s mm^-1'%self.blA)
        self.bloodScatteringLabel.config(text='blood scattering is %s mm^-1'%self.blS)

    def closeGui(self):

        config = configparser.ConfigParser()
        #I was thinking about adding exceptions, but I see no sence now
        config['GLOBAL'] = {}
        config['GLOBAL']['eps']=str(7./3-4./3-1)#some black magic that i found on stackoverflow. Another way to define eps is using numpy

        config['photon'] = {}
        config['photon']['w'] = '1000'
        config['photon']['x']='0'
        config['photon']['y']='0'
        config['photon']['z']='0'
        config['photon']['ux'] = '0'
        config['photon']['uy'] = '0'
        config['photon']['uz'] = '1'
        config['photon']['step'] = '0'
        config['photon']['n'] = '1.0'
        config['photon']['g'] = '0.8'

        config['tissue']={}
        config['tissue']['D']='1'
        config['tissue']['n'] = '1.4'
        config['tissue']['binSize'] = '0.005'
        config['tissue']['adA'] = str(self.adA)
        config['tissue']['adS'] = str(self.adS)
        config['tissue']['blA'] = str(self.blA)
        config['tissue']['blS'] = str(self.blS)

        with open('config.ini', 'w') as configfile:
            config.write(configfile)

        self.destroy()





