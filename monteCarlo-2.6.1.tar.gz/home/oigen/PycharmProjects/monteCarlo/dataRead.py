def readFromFile(path):
    """reads data from given path
    and writes it in the dictionary"""
    dictionary = {}
    file = open(path)
    for line in file:
        line = line.split('\t')
        line[1] = line[1].replace('\n', '')
        line[0] = float(line[0])
        line[1] = float(line[1])
        dictionary[line[0]] = line[1]
    file.close()
    return dictionary