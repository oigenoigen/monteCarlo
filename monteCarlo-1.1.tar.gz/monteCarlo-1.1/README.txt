Version 1.1
Now, there is only __init__ method for tissue.
To create tissue object, you can just write tissue=Tissue()
To run it, please run plot.py
