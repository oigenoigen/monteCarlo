import numpy
from configRead import config_read
class Tissue():
    def __init__(self):
        config=config_read()
        self.D=float(config['tissue']['D'])
        self.n=float(config['tissue']['n'])
        self.binSize=float(config['tissue']['binSize'])
        self.adA=float(config['tissue']['adA'])
        self.adS=float(config['tissue']['adS'])
        self.blA=float(config['tissue']['blA'])
        self.blS=float(config['tissue']['blS'])
        self.matrix = numpy.zeros((200, 200))

