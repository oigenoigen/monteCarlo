from initOfPhoton import Photon
from tissue import Tissue
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import matplotlib.pyplot as plt
import numpy
from GUI import gui
from configRead import config_read

gui()
conf=config_read()
eps=float(conf['GLOBAL']['eps'])#it has to be some kind of global variable and should not be calling here
#tissue object
tissue=Tissue()

for i in range(1000):
    #creating new photon object
    photon=Photon()
    #1e-15 is maximum resolved value
    while photon.w > eps:
        photon.hop(tissue)
        photon.spin()
        photon.drop(tissue)

fig = plt.figure()
#reference axises for 3d plot
xAxis=[x for x in range(200)]
yAxis=[x for x in range(200)]
#creating reference matrix for 3d plot, because plot_wireframe need 3 matrixes as arguments
xAxis,yAxis=numpy.meshgrid(xAxis,yAxis)
#some black magic
rezPlot=fig.gca(projection='3d')
surf=rezPlot.plot_surface(xAxis,yAxis,tissue.matrix, cmap=cm.coolwarm)
fig.colorbar(surf,shrink=0.5, aspect=5)
plt.show()
