
def getDictVal(wl,diction):
    dictKeys=[x for x in diction.keys()]
    diff=[abs(wl-k) for k in dictKeys]
    minKey=dictKeys[diff.index(min(diff))]
    minVal=diction[minKey]
    return minVal