import numpy
from GUI import gui
class Tissue():
    def __init__(self):
        self.D=1
        self.adA=None
        self.adS = None
        self.blA = None
        self.blS = None
        self.n=1.44
        self.matrix=numpy.zeros((200,200))
        self.binSize=0.005

    def getValues(self):
        values=gui()
        self.adA=values.adA*10
        self.adS=values.adS*10
        self.blA=values.blA*10
        self.blS=values.blS*10
        self.adMt=self.adA+self.adS