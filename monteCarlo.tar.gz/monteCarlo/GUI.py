from tkinter import *
from dataRead import readFromFile
from getDictVal import  getDictVal


class gui(Tk):
    def __init__(self):
        Tk.__init__(self)
        self.initialize()
        self.mainloop()


    def initialize(self):


        self.adiposeAbsorbtion = readFromFile("adipose_absorbtion.txt")
        self.adiposeScattering = readFromFile("adipose_scattering.txt")
        self.bloodAbsorbtion = readFromFile("blood_absorbtion.txt")
        self.bloodScattering = readFromFile("blood_scattering.txt")


        self.title("Select the wavelength")
        self.geometry('500x400+300+200')
        #TODO change textfields to labels if it`s possible in this case

        self.adiposeAbsorbtionLabel = Label(self,text="")
        self.adiposeAbsorbtionLabel.place(x=300, y=150)

        self.adiposeScatteringLabel = Label(self,text="")
        self.adiposeScatteringLabel.place(x=300, y=200)

        self.bloodAbsorbtionLabel = Label(self,text="")
        self.bloodAbsorbtionLabel.place(x=300, y=250)

        self.bloodScatteringLabel = Label(self,text="")
        self.bloodScatteringLabel.place(x=300, y=300)

        self.wLScale = Scale(self, orient=HORIZONTAL, length=300, from_=300, to=900, tickinterval=50)
        self.wLScale.place(x=100, y=50)

        self.getValButton = Button(self, text="Get values",command=self.getValues)
        self.getValButton.place(x=100, y=225)

        self.instructionLabel=Label(self,text="After getting values, please, close window to continue")
        self.instructionLabel.place(x=100,y=20)

    def getValues(self):

        wl=self.wLScale.get()

        self.adA=getDictVal(wl,self.adiposeAbsorbtion)
        self.adS=getDictVal(wl,self.adiposeScattering)
        self.blA=getDictVal(wl,self.bloodAbsorbtion)
        self.blS=getDictVal(wl,self.bloodScattering)

        self.adiposeAbsorbtionLabel.config(text=self.adA)
        self.adiposeScatteringLabel.config(text=self.adS)
        self.bloodAbsorbtionLabel.config(text=self.blA)
        self.bloodScatteringLabel.config(text=self.blS)

    def closeGui(self):
        self.destroy()





