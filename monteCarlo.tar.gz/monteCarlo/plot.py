import matplotlib.pyplot as plt
from initOfPhoton import Photon
from tissue import Tissue
import numpy
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter

tissue=Tissue()
tissue.getValues()

fig=plt.figure()

for i in range(1000):
    M=[]
    photon=Photon()
    while photon.w > 1e-15:
        photon.hop(tissue)
        photon.spin()
        photon.drop(tissue)
        M.append([photon.x,photon.y,photon.z])

    ax=fig.gca(projection='3d')

    X=[v[0] for v in M]
    Y=[v[1] for v in M]
    Z=[v[2] for v in M]

    ax.plot(X,Y,Z)
plt.show()
fig1=plt.figure()
#ax=fig.gca(projection='3d')
#X=numpy.arange(0,1,199)
#Y=numpy.arange(0,1,199)
#X,Y=numpy.meshgrid(X,Y)
#Z=tissue.matrix
#surf=ax.plot_surface(X,Y,Z, cmap=cm.coolwarm, linewidth=0)
#fig.colorbar(surf, shrink=0.5,aspect=5)
plt.imshow(tissue.matrix)
plt.show()
